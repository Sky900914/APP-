package com.example.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class ReminderBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("Reminder", "Received broadcast"); // 加入這行
        // 在這裡處理提醒的邏輯，例如顯示通知
        Toast.makeText(context, "該挑選午餐了！", Toast.LENGTH_SHORT).show();
    }
}
